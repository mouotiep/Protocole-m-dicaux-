package com.example.protocolesmed.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ProtocolDao {

    @Query("SELECT * FROM diseases WHERE specialtyId = :specialtyId ORDER BY frequencyRank ASC")
    fun observeDiseases(specialtyId: String): Flow<List<DiseaseEntity>>

    @Query("SELECT * FROM diseases WHERE id = :diseaseId LIMIT 1")
    fun observeDisease(diseaseId: Long): Flow<DiseaseEntity?>

    @Query("DELETE FROM diseases WHERE specialtyId = :specialtyId")
    suspend fun clearSpecialty(specialtyId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(diseases: List<DiseaseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRefresh(refresh: SpecialtyRefreshEntity)

    @Query("SELECT * FROM specialty_refresh WHERE specialtyId = :specialtyId LIMIT 1")
    suspend fun getRefresh(specialtyId: String): SpecialtyRefreshEntity?

    @Query("SELECT * FROM specialty_refresh")
    fun observeAllRefreshes(): Flow<List<SpecialtyRefreshEntity>>

    /**
     * Remplace l'intégralité des affections d'une spécialité en une seule transaction
     * (évite un état intermédiaire vide visible à l'écran pendant l'actualisation).
     */
    @Transaction
    suspend fun replaceSpecialtyDiseases(specialtyId: String, diseases: List<DiseaseEntity>, refreshedAt: Long) {
        clearSpecialty(specialtyId)
        insertAll(diseases)
        upsertRefresh(SpecialtyRefreshEntity(specialtyId, refreshedAt))
    }
}
