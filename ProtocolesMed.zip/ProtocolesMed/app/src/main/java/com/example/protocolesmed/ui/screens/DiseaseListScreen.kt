package com.example.protocolesmed.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.protocolesmed.data.Specialties
import com.example.protocolesmed.data.repository.ProtocolRepository
import com.example.protocolesmed.ui.viewmodel.DiseaseListViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiseaseListScreen(
    specialtyId: String,
    repository: ProtocolRepository,
    onBack: () -> Unit,
    onDiseaseClick: (diseaseId: Long) -> Unit
) {
    val specialty = Specialties.byId(specialtyId)
    val viewModel: DiseaseListViewModel = viewModel(
        factory = DiseaseListViewModel.Factory(specialtyId, repository)
    )
    val diseases by viewModel.diseases.collectAsState()
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(specialty?.displayName ?: "Spécialité") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refreshNow() }, enabled = !uiState.isRefreshing) {
                        if (uiState.isRefreshing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.Refresh, contentDescription = "Actualiser")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            LastRefreshBanner(lastRefreshed = uiState.lastRefreshed, errorMessage = uiState.errorMessage)

            if (diseases.isEmpty() && !uiState.isRefreshing) {
                EmptyState(onRefresh = { viewModel.refreshNow() })
            } else {
                LazyColumn(contentPadding = PaddingValues(vertical = 4.dp)) {
                    items(diseases) { disease ->
                        ListItem(
                            headlineContent = {
                                Text("${disease.frequencyRank}. ${disease.name}", fontWeight = FontWeight.Medium)
                            },
                            supportingContent = {
                                Text(
                                    disease.definition.take(90) +
                                        if (disease.definition.length > 90) "…" else ""
                                )
                            },
                            modifier = Modifier.clickable { onDiseaseClick(disease.id) }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
private fun LastRefreshBanner(lastRefreshed: Long?, errorMessage: String?) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        val label = if (lastRefreshed != null) {
            val formatted = SimpleDateFormat("dd/MM/yyyy à HH:mm", Locale.FRENCH)
                .format(Date(lastRefreshed))
            "Dernière actualisation : $formatted"
        } else {
            "Jamais actualisé — appuie sur le bouton actualiser en haut à droite."
        }
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Erreur : $errorMessage",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
private fun EmptyState(onRefresh: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Aucune donnée locale pour cette spécialité.",
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onRefresh) {
            Text("Actualiser maintenant")
        }
    }
}
