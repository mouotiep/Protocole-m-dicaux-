package com.example.protocolesmed.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.protocolesmed.data.Specialties

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpecialtyListScreen(
    onSpecialtyClick: (specialtyId: String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Protocoles internationaux") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(Specialties.ALL) { specialty ->
                ListItem(
                    headlineContent = {
                        Text(specialty.displayName, fontWeight = FontWeight.Medium)
                    },
                    trailingContent = {
                        Icon(Icons.Filled.ChevronRight, contentDescription = null)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSpecialtyClick(specialty.id) }
                )
                HorizontalDivider()
            }
        }
    }
}
