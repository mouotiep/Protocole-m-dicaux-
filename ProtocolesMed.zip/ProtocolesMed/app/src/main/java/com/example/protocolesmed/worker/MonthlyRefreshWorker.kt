package com.example.protocolesmed.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.protocolesmed.di.AppContainer

/**
 * Tâche exécutée automatiquement une fois par mois (planifiée dans ProtocolesApp)
 * pour actualiser TOUTES les spécialités. Peut aussi être déclenchée manuellement
 * en one-shot depuis un écran pour une seule spécialité (voir MainViewModel).
 */
class MonthlyRefreshWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val repository = AppContainer.get(applicationContext).repository
        return try {
            val results = repository.refreshAllSpecialties()
            val hasFailures = results.any { it.second.isFailure }
            if (hasFailures) Result.retry() else Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val UNIQUE_WORK_NAME = "monthly_protocol_refresh"
    }
}
