package com.example.protocolesmed.data.remote

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Client minimal pour l'API Gemini (generateContent) avec Grounding via Google Search,
 * pour limiter les hallucinations sur les données médicales.
 *
 * Nécessite une clé API (BuildConfig.GEMINI_API_KEY), lue depuis local.properties.
 */
class GeminiApiClient(private val apiKey: String) {

    private val model = "gemini-3.5-flash"
    private val baseUrl = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val requestAdapter = moshi.adapter(GeminiRequest::class.java)
    private val responseAdapter = moshi.adapter(GeminiResponse::class.java)
    private val diseaseListAdapter = moshi.adapter(DiseaseListResponse::class.java)

    sealed class Result {
        data class Success(val diseases: List<DiseaseJson>) : Result()
        data class Error(val message: String) : Result()
    }

    suspend fun fetchDiseasesForSpecialty(specialtyName: String, count: Int = 10): Result =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) {
                return@withContext Result.Error(
                    "Clé API Gemini manquante. Ajoute GEMINI_API_KEY dans local.properties."
                )
            }

            val prompt = buildPrompt(specialtyName, count)

            val geminiRequest = GeminiRequest(
                contents = listOf(GeminiContent(parts = listOf(GeminiPart(prompt)))),
                tools = listOf(GeminiTool(google_search = emptyMap())),
                generationConfig = GeminiGenerationConfig(temperature = 0.2)
            )

            val body = requestAdapter.toJson(geminiRequest)
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(baseUrl)
                .addHeader("x-goog-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            try {
                httpClient.newCall(request).execute().use { response ->
                    val rawBody = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext Result.Error(
                            "Erreur API Gemini (${response.code}): ${rawBody.take(300)}"
                        )
                    }

                    val parsed = responseAdapter.fromJson(rawBody)
                    val text = parsed?.candidates
                        ?.firstOrNull()
                        ?.content
                        ?.parts
                        ?.firstOrNull()
                        ?.text
                        ?: return@withContext Result.Error("Réponse vide du modèle.")

                    val cleanJson = extractJson(text)
                    val diseaseList = diseaseListAdapter.fromJson(cleanJson)
                        ?: return@withContext Result.Error("Impossible d'analyser le JSON retourné.")

                    Result.Success(diseaseList.diseases.sortedBy { it.rangFrequence })
                }
            } catch (e: Exception) {
                Result.Error("Échec réseau: ${e.message}")
            }
        }

    private fun buildPrompt(specialtyName: String, count: Int): String = """
        Tu es un assistant médical documentaliste. Utilise la recherche web pour t'appuyer
        sur les recommandations et protocoles internationaux en vigueur (OMS, sociétés savantes
        internationales telles que ESC, ATS/ERS, IDSA, KDIGO, NICE, ADA, etc.) pour la spécialité
        suivante : "$specialtyName".

        Liste les $count affections les PLUS FRÉQUENTES de cette spécialité, classées de la plus
        fréquente (rangFrequence = 1) à la moins fréquente (rangFrequence = $count).

        Pour chaque affection, rédige 6 sections textuelles concises (3 à 6 phrases chacune,
        texte brut uniquement, sans markdown, sans listes à puces) :
        - definition
        - epidemiologie
        - diagnostic
        - priseEnCharge (prise en charge / traitement selon les protocoles internationaux actuels)
        - surveillance
        - pronostic

        Réponds STRICTEMENT avec un JSON valide et rien d'autre (pas de texte avant/après, pas de
        balises markdown ```), au format exact suivant :
        {
          "diseases": [
            {
              "nom": "string",
              "rangFrequence": 1,
              "definition": "string",
              "epidemiologie": "string",
              "diagnostic": "string",
              "priseEnCharge": "string",
              "surveillance": "string",
              "pronostic": "string"
            }
          ]
        }
    """.trimIndent()

    /** Retire d'éventuelles balises ```json ... ``` autour de la réponse du modèle. */
    private fun extractJson(rawText: String): String {
        val trimmed = rawText.trim()
        val fenced = Regex("```(?:json)?\\s*([\\s\\S]*?)```")
        val match = fenced.find(trimmed)
        return match?.groupValues?.get(1)?.trim() ?: trimmed
    }
}
