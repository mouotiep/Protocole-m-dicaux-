package com.example.protocolesmed.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.protocolesmed.data.local.DiseaseEntity
import com.example.protocolesmed.data.repository.ProtocolRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DiseaseListUiState(
    val isRefreshing: Boolean = false,
    val lastRefreshed: Long? = null,
    val errorMessage: String? = null
)

class DiseaseListViewModel(
    private val specialtyId: String,
    private val repository: ProtocolRepository
) : ViewModel() {

    val diseases: StateFlow<List<DiseaseEntity>> = repository.observeDiseases(specialtyId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(DiseaseListUiState())
    val uiState: StateFlow<DiseaseListUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(lastRefreshed = repository.getLastRefresh(specialtyId))
        }
    }

    /** Déclenché par le bouton "Actualiser" : rafraîchissement immédiat, à la demande. */
    fun refreshNow() {
        if (_uiState.value.isRefreshing) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isRefreshing = true, errorMessage = null)
            val result = repository.refreshSpecialty(specialtyId)
            _uiState.value = _uiState.value.copy(
                isRefreshing = false,
                lastRefreshed = repository.getLastRefresh(specialtyId),
                errorMessage = result.exceptionOrNull()?.message
            )
        }
    }

    class Factory(
        private val specialtyId: String,
        private val repository: ProtocolRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DiseaseListViewModel(specialtyId, repository) as T
        }
    }
}
