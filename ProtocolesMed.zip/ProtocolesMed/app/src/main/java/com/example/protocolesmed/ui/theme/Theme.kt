package com.example.protocolesmed.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PrimaryTeal = Color(0xFF0B5D6B)
private val SecondaryTeal = Color(0xFF3E8E9E)

private val LightColors = lightColorScheme(
    primary = PrimaryTeal,
    secondary = SecondaryTeal
)

private val DarkColors = darkColorScheme(
    primary = SecondaryTeal,
    secondary = PrimaryTeal
)

@Composable
fun ProtocolesMedTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
