package com.example.protocolesmed.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Une affection au sein d'une spécialité, avec ses 6 sections textuelles.
 * [frequencyRank] : 1 = affection la plus fréquente de la spécialité.
 * [lastUpdated] : timestamp (epoch millis) de la dernière actualisation via l'API.
 */
@Entity(tableName = "diseases")
data class DiseaseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val specialtyId: String,
    val name: String,
    val frequencyRank: Int,
    val definition: String,
    val epidemiologie: String,
    val diagnostic: String,
    val priseEnCharge: String,
    val surveillance: String,
    val pronostic: String,
    val lastUpdated: Long
)
