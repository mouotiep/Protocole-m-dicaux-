package com.example.protocolesmed.data

/**
 * Liste des spécialités médicales suivies par l'application.
 * Cette liste est purement une catégorisation (pas un contenu médical en soi) :
 * le contenu de chaque affection est généré/actualisé via l'API Gemini.
 * Tu peux ajouter ou retirer des spécialités ici librement.
 */
data class Specialty(
    val id: String,
    val displayName: String
)

object Specialties {
    val ALL = listOf(
        Specialty("cardiologie", "Cardiologie"),
        Specialty("pneumologie", "Pneumologie"),
        Specialty("gastro_enterologie", "Gastro-entérologie"),
        Specialty("endocrinologie", "Endocrinologie & Diabétologie"),
        Specialty("nephrologie", "Néphrologie"),
        Specialty("neurologie", "Neurologie"),
        Specialty("infectiologie", "Infectiologie"),
        Specialty("rhumatologie", "Rhumatologie"),
        Specialty("dermatologie", "Dermatologie"),
        Specialty("hematologie", "Hématologie"),
        Specialty("psychiatrie", "Psychiatrie"),
        Specialty("gynecologie_obstetrique", "Gynécologie-Obstétrique"),
        Specialty("pediatrie", "Pédiatrie"),
        Specialty("oncologie", "Oncologie")
    )

    fun byId(id: String): Specialty? = ALL.find { it.id == id }
}
