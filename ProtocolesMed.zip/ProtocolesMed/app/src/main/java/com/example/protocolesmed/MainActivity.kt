package com.example.protocolesmed

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.protocolesmed.di.AppContainer
import com.example.protocolesmed.ui.screens.DiseaseDetailScreen
import com.example.protocolesmed.ui.screens.DiseaseListScreen
import com.example.protocolesmed.ui.screens.SpecialtyListScreen
import com.example.protocolesmed.ui.theme.ProtocolesMedTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = AppContainer.get(applicationContext).repository

        setContent {
            ProtocolesMedTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()

                    NavHost(navController = navController, startDestination = "specialties") {
                        composable("specialties") {
                            SpecialtyListScreen(
                                onSpecialtyClick = { specialtyId ->
                                    navController.navigate("specialty/$specialtyId")
                                }
                            )
                        }

                        composable(
                            route = "specialty/{specialtyId}",
                            arguments = listOf(navArgument("specialtyId") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val specialtyId = backStackEntry.arguments?.getString("specialtyId").orEmpty()
                            DiseaseListScreen(
                                specialtyId = specialtyId,
                                repository = repository,
                                onBack = { navController.popBackStack() },
                                onDiseaseClick = { diseaseId ->
                                    navController.navigate("disease/$diseaseId")
                                }
                            )
                        }

                        composable(
                            route = "disease/{diseaseId}",
                            arguments = listOf(navArgument("diseaseId") { type = NavType.LongType })
                        ) { backStackEntry ->
                            val diseaseId = backStackEntry.arguments?.getLong("diseaseId") ?: -1L
                            DiseaseDetailScreen(
                                diseaseId = diseaseId,
                                repository = repository,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
