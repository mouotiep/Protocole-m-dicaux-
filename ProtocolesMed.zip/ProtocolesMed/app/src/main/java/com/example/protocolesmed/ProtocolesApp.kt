package com.example.protocolesmed

import android.app.Application
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.protocolesmed.worker.MonthlyRefreshWorker
import java.util.concurrent.TimeUnit

/**
 * Point d'entrée de l'application.
 * Programme au démarrage la tâche mensuelle d'actualisation automatique
 * des protocoles pour toutes les spécialités.
 */
class ProtocolesApp : Application() {

    override fun onCreate() {
        super.onCreate()
        scheduleMonthlyRefresh()
    }

    private fun scheduleMonthlyRefresh() {
        val request = PeriodicWorkRequestBuilder<MonthlyRefreshWorker>(
            30, TimeUnit.DAYS
        ).build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            MonthlyRefreshWorker.UNIQUE_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
