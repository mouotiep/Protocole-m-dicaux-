package com.example.protocolesmed.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "specialty_refresh")
data class SpecialtyRefreshEntity(
    @PrimaryKey val specialtyId: String,
    val lastRefreshed: Long
)
