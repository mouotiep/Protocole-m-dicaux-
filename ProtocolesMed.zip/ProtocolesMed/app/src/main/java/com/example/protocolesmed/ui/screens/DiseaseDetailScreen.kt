package com.example.protocolesmed.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.protocolesmed.data.local.DiseaseEntity
import com.example.protocolesmed.data.repository.ProtocolRepository

private data class Section(val title: String, val content: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiseaseDetailScreen(
    diseaseId: Long,
    repository: ProtocolRepository,
    onBack: () -> Unit
) {
    val disease by repository.observeDisease(diseaseId).collectAsState(initial = null)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(disease?.name ?: "Détail") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Retour")
                    }
                }
            )
        }
    ) { padding ->
        val current = disease
        if (current == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            DiseaseSections(current, modifier = Modifier.padding(padding))
        }
    }
}

@Composable
private fun DiseaseSections(disease: DiseaseEntity, modifier: Modifier = Modifier) {
    val sections = listOf(
        Section("Définition", disease.definition),
        Section("Épidémiologie", disease.epidemiologie),
        Section("Diagnostic", disease.diagnostic),
        Section("Prise en charge", disease.priseEnCharge),
        Section("Surveillance", disease.surveillance),
        Section("Pronostic", disease.pronostic)
    )

    var selectedTab by remember { mutableIntStateOf(0) }

    Column(modifier = modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 12.dp) {
            sections.forEachIndexed { index, section ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(section.title) }
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                sections[selectedTab].title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            val bodyText = sections[selectedTab].content.ifBlank {
                "Aucune information disponible pour cette section. Actualise la spécialité pour la générer."
            }
            Text(bodyText, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
