package com.example.protocolesmed.di

import android.content.Context
import com.example.protocolesmed.BuildConfig
import com.example.protocolesmed.data.local.AppDatabase
import com.example.protocolesmed.data.remote.GeminiApiClient
import com.example.protocolesmed.data.repository.ProtocolRepository

/**
 * Petit conteneur de dépendances "à la main" (pas de Hilt/Koin pour rester simple).
 * Accessible depuis n'importe où via AppContainer.get(context).
 */
class AppContainer private constructor(context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val apiClient = GeminiApiClient(BuildConfig.GEMINI_API_KEY)
    val repository = ProtocolRepository(database.protocolDao(), apiClient)

    companion object {
        @Volatile
        private var INSTANCE: AppContainer? = null

        fun get(context: Context): AppContainer =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: AppContainer(context.applicationContext).also { INSTANCE = it }
            }
    }
}
