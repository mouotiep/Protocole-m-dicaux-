package com.example.protocolesmed.data.remote

/**
 * Schéma JSON attendu en réponse du modèle pour une spécialité donnée.
 * Correspond exactement aux instructions du prompt envoyé à Gemini.
 */
data class DiseaseListResponse(
    val diseases: List<DiseaseJson> = emptyList()
)

data class DiseaseJson(
    val nom: String = "",
    val rangFrequence: Int = 0,
    val definition: String = "",
    val epidemiologie: String = "",
    val diagnostic: String = "",
    val priseEnCharge: String = "",
    val surveillance: String = "",
    val pronostic: String = ""
)

// --- Modèles bruts de l'API Gemini generateContent ---

data class GeminiRequest(
    val contents: List<GeminiContent>,
    val tools: List<GeminiTool>? = null,
    val generationConfig: GeminiGenerationConfig? = null
)

data class GeminiContent(
    val parts: List<GeminiPart>
)

data class GeminiPart(
    val text: String
)

data class GeminiTool(
    val google_search: Map<String, String> = emptyMap()
)

data class GeminiGenerationConfig(
    val temperature: Double = 0.3
)

data class GeminiResponse(
    val candidates: List<GeminiCandidate>? = null
)

data class GeminiCandidate(
    val content: GeminiContent? = null
)
