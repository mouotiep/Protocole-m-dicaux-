package com.example.protocolesmed.data.repository

import com.example.protocolesmed.data.Specialties
import com.example.protocolesmed.data.local.DiseaseEntity
import com.example.protocolesmed.data.local.ProtocolDao
import com.example.protocolesmed.data.local.SpecialtyRefreshEntity
import com.example.protocolesmed.data.remote.GeminiApiClient
import kotlinx.coroutines.flow.Flow

class ProtocolRepository(
    private val dao: ProtocolDao,
    private val apiClient: GeminiApiClient
) {

    fun observeDiseases(specialtyId: String): Flow<List<DiseaseEntity>> =
        dao.observeDiseases(specialtyId)

    fun observeDisease(diseaseId: Long): Flow<DiseaseEntity?> =
        dao.observeDisease(diseaseId)

    fun observeAllRefreshes(): Flow<List<SpecialtyRefreshEntity>> =
        dao.observeAllRefreshes()

    suspend fun getLastRefresh(specialtyId: String): Long? =
        dao.getRefresh(specialtyId)?.lastRefreshed

    /** Actualise une seule spécialité (bouton "Actualiser" côté écran). */
    suspend fun refreshSpecialty(specialtyId: String): Result<Unit> {
        val specialty = Specialties.byId(specialtyId)
            ?: return Result.failure(IllegalArgumentException("Spécialité inconnue : $specialtyId"))

        return when (val result = apiClient.fetchDiseasesForSpecialty(specialty.displayName)) {
            is GeminiApiClient.Result.Success -> {
                val now = System.currentTimeMillis()
                val entities = result.diseases.map { json ->
                    DiseaseEntity(
                        specialtyId = specialtyId,
                        name = json.nom,
                        frequencyRank = json.rangFrequence,
                        definition = json.definition,
                        epidemiologie = json.epidemiologie,
                        diagnostic = json.diagnostic,
                        priseEnCharge = json.priseEnCharge,
                        surveillance = json.surveillance,
                        pronostic = json.pronostic,
                        lastUpdated = now
                    )
                }
                dao.replaceSpecialtyDiseases(specialtyId, entities, now)
                Result.success(Unit)
            }
            is GeminiApiClient.Result.Error -> Result.failure(Exception(result.message))
        }
    }

    /** Actualise toutes les spécialités (utilisé par la tâche mensuelle automatique). */
    suspend fun refreshAllSpecialties(): List<Pair<String, Result<Unit>>> {
        return Specialties.ALL.map { specialty ->
            specialty.id to refreshSpecialty(specialty.id)
        }
    }
}
