# Protocoles Med

Application Android (Kotlin + Jetpack Compose) qui recense, par spécialité médicale, les
affections les plus fréquentes avec un résumé des protocoles internationaux de prise en charge
(OMS, sociétés savantes internationales...), classées de la plus fréquente à la moins fréquente.

Pour chaque affection, 6 sections textuelles : **Définition, Épidémiologie, Diagnostic,
Prise en charge, Surveillance, Pronostic**.

## Comment ça marche

- Le contenu **n'est pas codé en dur** : il est généré par l'API **Gemini** (avec recherche
  Google activée comme "grounding", pour limiter les erreurs/hallucinations et s'appuyer sur des
  informations à jour) puis mis en cache localement (base Room) pour un accès hors-ligne rapide.
- Une tâche automatique (**WorkManager**) relance la génération **une fois par mois** pour
  toutes les spécialités.
- Sur l'écran de chaque spécialité, un **bouton "Actualiser"** (icône ↻ en haut à droite) permet
  de forcer une actualisation immédiate à tout moment.

⚠️ Important : les résultats sont générés par une IA. Même avec la recherche web activée, il
reste indispensable qu'un professionnel de santé vérifie les informations avant toute utilisation
clinique. Cette app est un outil d'aide-mémoire, pas une source médicale certifiée.

## Configuration avant de compiler

1. Récupère une clé API Gemini gratuite sur https://aistudio.google.com/app/apikey
2. À la racine du projet, copie `local.properties.example` en `local.properties`
3. Renseigne :
   ```
   GEMINI_API_KEY=ta_cle_ici
   sdk.dir=/chemin/vers/ton/Android/sdk
   ```
4. Compile :
   ```
   ./gradlew assembleDebug
   ```
   L'APK sera dans `app/build/outputs/apk/debug/app-debug.apk`

## Build automatique sur GitHub Actions

Le workflow `.github/workflows/android.yml` build l'APK à chaque push. Pour qu'il fonctionne,
ajoute ta clé dans **Settings > Secrets and variables > Actions** du repo GitHub, sous le nom
`GEMINI_API_KEY`.

## Personnaliser les spécialités

La liste des spécialités suivies se trouve dans :
`app/src/main/java/com/example/protocolesmed/data/Specialty.kt`
Ajoute ou retire une ligne pour changer la liste — aucune autre modification n'est nécessaire.
